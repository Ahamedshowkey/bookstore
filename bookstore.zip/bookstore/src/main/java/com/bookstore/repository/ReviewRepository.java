package com.bookstore.repository;

import com.bookstore.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    
    // Fix the method name - it should be "BookId" not "Bookld" (lowercase L vs uppercase i)
    List<Review> findByBookIdAndApprovedTrue(Long bookId);
    
    List<Review> findByBookId(Long bookId);
    
    List<Review> findByApprovedFalse();
    
    List<Review> findByUserId(Long userId);
}