package com.bookstore.config;

import com.bookstore.entity.Book;
import com.bookstore.entity.Role;
import com.bookstore.entity.User;
import com.bookstore.repository.BookRepository;
import com.bookstore.repository.RoleRepository;
import com.bookstore.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final BookRepository bookRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create roles
        if (roleRepository.count() == 0) {
            Role adminRole = new Role("ADMIN");
            Role customerRole = new Role("CUSTOMER");
            roleRepository.save(adminRole);
            roleRepository.save(customerRole);
            System.out.println("=== Roles created successfully ===");
        }

        // Create admin user
        if (userRepository.findByUsername("admin").isEmpty()) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setEmail("admin@bookstore.com");
            admin.setFirstName("Admin");
            admin.setLastName("User");
            admin.setCreatedAt(LocalDateTime.now()); // Set createdAt field

            Role adminRole = roleRepository.findByName("ADMIN")
                .orElseThrow(() -> new RuntimeException("ADMIN role not found"));
            admin.setRoles(Collections.singleton(adminRole));

            userRepository.save(admin);
            System.out.println("=== Admin user created ===");
            System.out.println("Username: admin, Password: admin123");
        }

        // Create customer user
        if (userRepository.findByUsername("customer").isEmpty()) {
            User customer = new User();
            customer.setUsername("customer");
            customer.setPassword(passwordEncoder.encode("customer123"));
            customer.setEmail("customer@bookstore.com");
            customer.setFirstName("John");
            customer.setLastName("Doe");
            customer.setCreatedAt(LocalDateTime.now()); // Set createdAt field

            Role customerRole = roleRepository.findByName("CUSTOMER")
                .orElseThrow(() -> new RuntimeException("CUSTOMER role not found"));
            customer.setRoles(Collections.singleton(customerRole));

            userRepository.save(customer);
            System.out.println("=== Customer user created ===");
            System.out.println("Username: customer, Password: customer123");
        }

        // Create sample books - Use setter methods instead of constructor
        if (bookRepository.count() == 0) {
            Book book1 = new Book();
            book1.setTitle("The Great Gatsby");
            book1.setAuthor("F. Scott Fitzgerald");
            book1.setIsbn("9780743273565");
            book1.setDescription("A classic novel of the Jazz Age");
            book1.setPrice(new BigDecimal("12.99"));
            book1.setStockQuantity(50);
            book1.setImageUrl("/images/great-gatsby.jpg");

            Book book2 = new Book();
            book2.setTitle("To Kill a Mockingbird");
            book2.setAuthor("Harper Lee");
            book2.setIsbn("9780061120084");
            book2.setDescription("A gripping tale of racial injustice");
            book2.setPrice(new BigDecimal("14.99"));
            book2.setStockQuantity(30);
            book2.setImageUrl("/images/mockingbird.jpg");

            Book book3 = new Book();
            book3.setTitle("1984");
            book3.setAuthor("George Orwell");
            book3.setIsbn("9780451524935");
            book3.setDescription("A dystopian social science fiction novel");
            book3.setPrice(new BigDecimal("10.99"));
            book3.setStockQuantity(25);
            book3.setImageUrl("/images/1984.jpg");

            Book book4 = new Book();
            book4.setTitle("Pride and Prejudice");
            book4.setAuthor("Jane Austen");
            book4.setIsbn("9780141439518");
            book4.setDescription("A romantic novel of manners");
            book4.setPrice(new BigDecimal("11.99"));
            book4.setStockQuantity(40);
            book4.setImageUrl("/images/pride-prejudice.jpg");

            Book book5 = new Book();
            book5.setTitle("The Hobbit");
            book5.setAuthor("J.R.R. Tolkien");
            book5.setIsbn("9780547928227");
            book5.setDescription("A fantasy novel and children's book");
            book5.setPrice(new BigDecimal("13.99"));
            book5.setStockQuantity(35);
            book5.setImageUrl("/images/hobbit.jpg");

            Book book6 = new Book();
            book6.setTitle("Harry Potter and the Philosopher's Stone");
            book6.setAuthor("J.K. Rowling");
            book6.setIsbn("9780747532743");
            book6.setDescription("The first novel in the Harry Potter series");
            book6.setPrice(new BigDecimal("15.99"));
            book6.setStockQuantity(60);
            book6.setImageUrl("/images/harry-potter.jpg");

            Book book7 = new Book();
            book7.setTitle("The Catcher in the Rye");
            book7.setAuthor("J.D. Salinger");
            book7.setIsbn("9780316769174");
            book7.setDescription("A controversial novel originally published for adults");
            book7.setPrice(new BigDecimal("9.99"));
            book7.setStockQuantity(20);
            book7.setImageUrl("/images/catcher-rye.jpg");

            bookRepository.save(book1);
            bookRepository.save(book2);
            bookRepository.save(book3);
            bookRepository.save(book4);
            bookRepository.save(book5);
            bookRepository.save(book6);
            bookRepository.save(book7);
            
            System.out.println("=== Sample books created ===");
        }
    }
}
