package com.bookstore.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // ✅ ADD THIS LINE - Disable CSRF for development
            .authorizeHttpRequests(authz -> authz
                // Public pages
                .requestMatchers(
                    "/", "/home", "/index", 
                    "/books", "/books/**", 
                    "/register", "/login", 
                    "/css/**", "/js/**", "/images/**", "/webjars/**",
                    "/error"
                ).permitAll()
                
                // Admin pages - ✅ FIX: Remove ROLE_ prefix since Spring adds it automatically
                .requestMatchers("/admin/**").hasRole("ADMIN")
                
                // Customer pages
                .requestMatchers(
                    "/customer/**", 
                    "/cart", "/cart/**", 
                    "/checkout", "/checkout/**", 
                    "/orders", "/orders/**",
                    "/profile"
                ).hasRole("CUSTOMER")
                
                // Authenticated users only
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/default", true)
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout=true")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            )
            .exceptionHandling(ex -> ex
                .accessDeniedPage("/access-denied")
            );

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}