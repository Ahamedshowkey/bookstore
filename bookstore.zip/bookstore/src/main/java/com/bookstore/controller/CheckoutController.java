package com.bookstore.controller;

import com.bookstore.entity.User;
import com.bookstore.repository.UserRepository;
import com.bookstore.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequiredArgsConstructor
public class CheckoutController {

    private final OrderService orderService;
    private final UserRepository userRepository;

    @PostMapping("/checkout")
    public String checkout(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            try {
                orderService.placeOrder(user);
                return "redirect:/orders?success";
            } catch (Exception e) {
                return "redirect:/cart?error=" + e.getMessage();
            }
        }
        return "redirect:/login";
    }
}