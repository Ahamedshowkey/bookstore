package com.bookstore.controller;

import com.bookstore.entity.Book;
import com.bookstore.entity.Order;
import com.bookstore.entity.User;
import com.bookstore.service.BookService;
import com.bookstore.service.OrderService;
import com.bookstore.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final BookService bookService;
    private final OrderService orderService;
    private final UserService userService;

    // Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<Book> books = bookService.findAll();
        List<Order> orders = orderService.getAllOrders();
        List<User> users = userService.getAllUsers();
        
        long totalBooks = books.size();
        long lowStockBooks = books.stream()
            .filter(book -> book.getStockQuantity() != null && book.getStockQuantity() < 10)
            .count();
        long totalOrders = orders.size();
        long totalCustomers = users.stream()
            .filter(user -> user.getRoles().stream().anyMatch(role -> role.getName().equals("CUSTOMER")))
            .count();
        
        model.addAttribute("totalBooks", totalBooks);
        model.addAttribute("lowStockBooks", lowStockBooks);
        model.addAttribute("totalOrders", totalOrders);
        model.addAttribute("totalCustomers", totalCustomers);
        model.addAttribute("pageTitle", "Admin Dashboard");
        return "admin/dashboard";
    }

    // Book Management
    @GetMapping("/books")
    public String books(Model model) {
        List<Book> books = bookService.findAll();
        model.addAttribute("books", books);
        model.addAttribute("pageTitle", "Manage Books");
        return "admin/books";
    }

    @GetMapping("/books/new")
    public String showBookForm(Model model) {
        model.addAttribute("book", new Book());
        model.addAttribute("pageTitle", "Add New Book");
        return "admin/book-form";
    }

    @PostMapping("/books/save")
    public String saveBook(@ModelAttribute Book book) {
        if (book.getStockQuantity() == null) {
            book.setStockQuantity(0);
        }
        bookService.save(book);
        return "redirect:/admin/books";
    }

    @GetMapping("/books/edit/{id}")
    public String editBook(@PathVariable Long id, Model model) {
        Book book = bookService.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid book id: " + id));
        model.addAttribute("book", book);
        model.addAttribute("pageTitle", "Edit Book");
        return "admin/book-form";
    }

    @GetMapping("/books/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        if (bookService.findById(id).isPresent()) {
            bookService.deleteById(id);
        }
        return "redirect:/admin/books";
    }

    // Order Management
    @GetMapping("/orders")
    public String orders(Model model) {
        List<Order> orders = orderService.getAllOrders();
        model.addAttribute("orders", orders);
        model.addAttribute("pageTitle", "Manage Orders");
        return "admin/orders";
    }

    @GetMapping("/orders/{id}")
    public String viewOrder(@PathVariable Long id, Model model) {
        Order order = orderService.getOrderById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid order id: " + id));
        model.addAttribute("order", order);
        model.addAttribute("pageTitle", "Order Details");
        return "admin/order-details";
    }

    @PostMapping("/orders/{id}/update-status")
    public String updateOrderStatus(@PathVariable Long id, @RequestParam String status) {
        orderService.updateOrderStatus(id, status);
        return "redirect:/admin/orders/" + id;
    }

    // Customer Management
    @GetMapping("/customers")
    public String customers(Model model) {
        List<User> customers = userService.getAllCustomers();
        model.addAttribute("customers", customers);
        model.addAttribute("pageTitle", "Manage Customers");
        return "admin/customers";
    }

    @GetMapping("/customers/{id}")
    public String viewCustomer(@PathVariable Long id, Model model) {
        User customer = userService.getUserById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid customer id: " + id));
        model.addAttribute("customer", customer);
        model.addAttribute("pageTitle", "Customer Details");
        return "admin/customer-details";
    }
}