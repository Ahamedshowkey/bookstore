package com.bookstore.controller;

import com.bookstore.entity.Book;
import com.bookstore.entity.User;
import com.bookstore.repository.UserRepository;
import com.bookstore.service.BookService;
import com.bookstore.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;
    private final CartService cartService;
    private final UserRepository userRepository;

    @GetMapping("/{id}")
    public String getBookDetails(@PathVariable Long id, Model model, Authentication authentication) {
        Book book = bookService.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid book id: " + id));
        model.addAttribute("book", book);
        model.addAttribute("pageTitle", book.getTitle());
        
        // Add cart item count for authenticated users
        if (authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
            int cartItemCount = cartService.getCartItemCount(user);
            model.addAttribute("cartItemCount", cartItemCount);
        } else {
            model.addAttribute("cartItemCount", 0);
        }
        
        return "book-details";
    }

    @GetMapping
    public String getAllBooks(Model model, Authentication authentication) {
        List<Book> books = bookService.findAll();
        model.addAttribute("books", books);
        model.addAttribute("pageTitle", "All Books");
        
        // Add cart item count for authenticated users
        if (authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
            int cartItemCount = cartService.getCartItemCount(user);
            model.addAttribute("cartItemCount", cartItemCount);
        } else {
            model.addAttribute("cartItemCount", 0);
        }
        
        return "books";
    }

    @GetMapping("/search")
    public String searchBooks(@RequestParam String query, Model model, Authentication authentication) {
        List<Book> booksByTitle = bookService.searchByTitle(query);
        List<Book> booksByAuthor = bookService.searchByAuthor(query);
        
        // Combine results, remove duplicates
        booksByTitle.addAll(booksByAuthor.stream()
            .filter(book -> !booksByTitle.contains(book))
            .toList());
            
        model.addAttribute("books", booksByTitle);
        model.addAttribute("searchQuery", query);
        model.addAttribute("pageTitle", "Search Results for: " + query);
        
        // Add cart item count for authenticated users
        if (authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();
            User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
            int cartItemCount = cartService.getCartItemCount(user);
            model.addAttribute("cartItemCount", cartItemCount);
        } else {
            model.addAttribute("cartItemCount", 0);
        }
        
        return "books";
    }
}