package com.bookstore.service;

import com.bookstore.entity.Review;
import com.bookstore.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    public List<Review> getApprovedReviewsByBookId(Long bookId) {
        return reviewRepository.findByBookIdAndApprovedTrue(bookId);
    }

    public double getAverageRating(Long bookId) {
        List<Review> approvedReviews = getApprovedReviewsByBookId(bookId);
        if (approvedReviews.isEmpty()) {
            return 0.0;
        }
        
        return approvedReviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0);
    }

    public Review saveReview(Review review) {
        return reviewRepository.save(review);
    }
    
    public List<Review> getPendingReviews() {
        return reviewRepository.findByApprovedFalse();
    }
    
    public void approveReview(Long reviewId) {
        Review review = reviewRepository.findById(reviewId).orElse(null);
        if (review != null) {
            review.setApproved(true);
            reviewRepository.save(review);
        }
    }
    
    public void deleteReview(Long reviewId) {
        reviewRepository.deleteById(reviewId);
    }
}